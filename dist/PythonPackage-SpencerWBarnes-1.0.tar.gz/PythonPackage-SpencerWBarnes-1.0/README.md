# PythonPackage
 An introduction to making a publically available python package.

### Purpose
I was interested in using GitHub's ability to host packages. It would be a better idea to try out this process with an introductory package than an existing respository I care about. This package will be essentially useless as it will hold little to no valuable functionality.  
  
That is unless you wanted to try installing a python package from a public repo on GitHub, in which...  
**:tada: You did it! :tada:** <sub> I never even doubted you </sub>