# My favorite feature
def HelloWorld():
  print("HelloWorld")
  return

def Add(a, b):
  return a + b

def Subtract(a, b):
  return a - b

if __name__ == '__main__':
  HelloWorld()