# My favorite feature
def HelloWorld():
  print("HelloWorld")

if __name__ == '__main__':
  HelloWorld()