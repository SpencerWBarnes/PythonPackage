# My favorite feature
def HelloWorld():
  print('HelloWorld')
  return

def Echo(message):
  print(message)
  return

def Add(a, b):
  return a + b

def Subtract(a, b):
  return a - b

def Modulus(a, b):
  return a % b

def Lol():
  print('haha')
  return

if __name__ == '__main__':
  HelloWorld()